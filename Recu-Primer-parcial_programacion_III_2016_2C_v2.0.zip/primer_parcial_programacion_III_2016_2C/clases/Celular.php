<?php
class Celular {

//agregar atributos necesarios
    
    public function __construct($marca, $so, $cantSIM) {
        //IMPLEMENTAR...
    }
    
    public function Agregar() {
        //IMPLEMENTAR...
    }
}