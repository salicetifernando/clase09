<?php
class Mascota {

    public static function Eliminar($idMascota) {
        //IMPLEMENTAR...
    }
}
